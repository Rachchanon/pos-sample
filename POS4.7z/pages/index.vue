<template>
  <div class="container">
    <div>
      <logo />
      <h1 class="title">POS</h1>
      
      รายการสินค้าทั้งหมด*
      <div>{{allItem}}</div>

      <br />ข้อมูลสินค้าทั้งหมด ดึงจาก API*
      <div>{{allItemById}}</div>

      <br />รายการราคาทั้งหมด*
      <div>{{allListPrice}}</div>

      <br />index รายการสินค้าทั้งหมด*
      <div>{{allItemIndex}}</div>

      <br />รวมราคาสินค้าทั้งหมด*
      <div>{{sumPrice}}</div>
      
      <br />รายการที่มีส่วนลด*
      <div>{{listItem}}</div>

      <br />เซ็ทที่ได้ส่วนลด*
      <div>{{step2Filter}}</div>

      <br />ข้อมูลสินค้าที่ได้ส่วนลด ดึงจาก API*
      <div>{{step2FilterById}}</div>

      <br />รายการราคาส่วนลด*
      <div>{{step2ListPrice}}</div>

      <br />index ของรายการราคาส่วนลด*
      <div>{{step3ListIndex}}</div>

      <br />รวมส่วนลด*
      <div>{{sumDiscount}}</div>

      <br />เซ็ทที่ได้ส่วนลดที่ยังเหลือ*
      <div>{{step3Filter}}</div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      dataFromAPI: '',
      allItem: '',
      allItemIndex: [],
      allItemById: [],
      allListPrice: [],
      sumPrice: '',
      listItem: [],
      step2Filter: [],
      step2FilterById: [],
      step2ListPrice: [],
      step3Filter: [],
      step3ListIndex: [],
      sumDiscount: ''
    }
  },
  async mounted() {
    await this.fetchSomething()
    await this.filterProdustDiscount()
    await this.calcDiscount()
    await this.calcPrice()

    // ["9781408855652","9781408855669","9781408855676","9781408855683","9781408855690","9781408855706","9781408855713"]
    // "9780241392362"
  },
  methods: {
    async fetchSomething() {
      const res = await this.$axios.$get('https://api.jsonbin.io/b/5f3154b06f8e4e3faf2f99de')
      this.dataFromAPI = await res.books
      console.log('fetchSomething -> dataFromAPI', this.dataFromAPI)
    },
    async filterProdustDiscount() {
      let allItem = [
        "9781408855652",
        "9781408855669",
        "9781408855652",
        "9781408855669",
        "9781408855669",
        "9780241392362",
      ]
      this.allItem = allItem

      let listDiscount = [
        "9781408855652",
        "9781408855669",
        "9781408855676",
        "9781408855683",
        "9781408855690",
        "9781408855706",
        "9781408855713"
      ]

      //กรองเอาเฉพาะรายการที่มีส่วนลด
      let step1Filter = []

      allItem.forEach((e, index) => {
        listDiscount.forEach((e2, index) => {
          if (e == e2) {
            step1Filter.push(e2)
          }
        })
      })
      this.listItem = step1Filter.sortBy()
    },
    async calcDiscount() {
      // แยกรายการmที่มีส่วนลดเป็นเซ็ต
      let step2Filter
      let step2ListPrice = []
      let step2FilterById = []
      let listPriceByID = []

      if (!step2Filter) {
        step2Filter = []
        //เช็คหาเซ็ทสินค้าที่ตรงเงื่อนไข
        step2Filter = this.listItem.unique()
        this.step2Filter = step2Filter

        this.step2Filter.forEach((e, index) => {
          step2FilterById.push(
            this.dataFromAPI.find(book => {
              return book.id == e
            })
          )
          this.step2FilterById = step2FilterById
        })

        listPriceByID = step2FilterById.clone()
      }
      if (step2Filter) {
        // listPriceByID = this.step3Filter
        console.log(`listPriceByID`, listPriceByID);
        console.log(`this.step3Filter`, this.step3Filter);
      }

      //เอาเฉพาะราคาสินค้าทั้งหมด ที่มีส่วนลดออกมา
      listPriceByID.forEach((e, index) => {
        this.step2ListPrice.push(+e.price)
      })

      /* ============================================== */

      let step2Length = this.step2Filter.length

      //หาผลรวมของราคาส่วนลด
      let totalPrice = this.step2ListPrice.sum()
      console.log("calcDiscount -> totalPrice", totalPrice)

      //หาส่วนลดสำหรับ 2 ชิ้น discount 10%
      if (step2Length == 2) {
        totalPrice = totalPrice * 0.10
        console.log('2 ชิ้น ลด', totalPrice);
      }
      //หาส่วนลดสำหรับ 3 ชิ้น discount 11%
      if (step2Length == 3) {
        totalPrice = totalPrice * 0.11
        console.log('3 ชิ้น ลด', totalPrice);
      }
      //หาส่วนลดสำหรับ 4 ชิ้น discount 12%
      if (step2Length == 4) {
        totalPrice = totalPrice * 0.12
        console.log('4 ชิ้น ลด', totalPrice);
      }
      //หาส่วนลดสำหรับ 5 ชิ้น discount 13%
      if (step2Length == 5) {
        totalPrice = totalPrice * 0.13
        console.log('5 ชิ้น ลด', totalPrice);
      }
      //หาส่วนลดสำหรับ 6 ชิ้น discount 14%
      if (step2Length == 6) {
        totalPrice = totalPrice * 0.14
        console.log('6 ชิ้น ลด', totalPrice);
      }
      //หาส่วนลดสำหรับ 7 ชิ้น discount 15%
      if (step2Length == 7) {
        totalPrice = totalPrice * 0.15
        console.log('7 ชิ้น ลด', totalPrice);
      }

      this.sumDiscount = totalPrice

      //หา index ของ step2
      this.step2Filter.forEach((e, index) => {
        let i = this.listItem.findIndex(e)
        this.step3ListIndex.push(i)
      })

      /* ============================================== */

      this.reduceListItem()
    },
    async reduceListItem() {
      let step3Filter = []
      step3Filter = await this.listItem.clone()

      // ลบรายการที่แยกเซ็ตออกไป
      this.step3ListIndex.reverse().forEach((e, index) => {
        step3Filter.splice(e, 1)
      })

      this.step3Filter = await step3Filter.sortBy()

      /* ============================================== */

      //เช็คหาเซ็ทสินค้าที่ตรงเงื่อนไข
      let checkHaveDisCount = this.step3Filter.unique()

      if (checkHaveDisCount.length > 1) {
        this.calcDiscount()
      } else {
        this.step3Filter = []
      }
    },
    async calcPrice() {
      let allItemById = []

      this.allItem.forEach((e, index) => {
          allItemById.push(
            this.dataFromAPI.find(book => {
              return book.id == e
            })
          )
          this.allItemById = allItemById
        })

      //เอาเฉพาะราคาสินค้าทั้งหมดออกมา
      allItemById.forEach((e, index) => {
        this.allListPrice.push(+e.price)
      })

      //หาผลรวมของราคาสินค้าทั้งหมด
      let totalPrice = this.allListPrice.sum()
      this.sumPrice = totalPrice

      //หา index ของ allItem
      this.allItem.forEach((e, index) => {
        let i = this.allItem.findIndex(e)
        this.allItemIndex.push(i)
      })

      //กรองเอา array ที่ไม่ซ้ำกัน **ถ้าต้องได้ใช้
      // this.allItemIndex = [...new Set(this.allItemIndex)]
    }
  }
}
</script>

<style>
</style>
