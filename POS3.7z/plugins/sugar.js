import Vue from 'vue'
import sugar from 'sugar'

Vue.use(sugar)